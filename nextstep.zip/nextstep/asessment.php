<?php
session_start();
include "koneksi.php";

// Cek apakah sudah login
if(!isset($_SESSION['email'])){
    header("Location: login.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>NextStep.id - Assessment</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=Inter:wght@400;500;600&display=swap" rel="stylesheet"/>
  <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet"/>
  <style>
    body { font-family: 'Inter', sans-serif; background: #f8fafc; }
    .material-symbols-outlined { font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24; }
    .option-label input:checked ~ .option-box { border-color: #004ac6; background: #eff6ff; }
    .option-label input:checked ~ .option-box .option-letter { background: #004ac6; color: white; }
  </style>
</head>
<body class="min-h-screen flex items-center justify-center p-6">

<div class="w-full max-w-2xl">

  <!-- Header -->
  <div class="text-center mb-8">
    <h1 class="text-3xl font-extrabold text-blue-600 mb-1">NextStep.id</h1>
    <p class="text-slate-500 text-sm">Jawab jujur sesuai perasaanmu ya!</p>
  </div>

  <!-- Progress Bar -->
  <div class="mb-6">
    <div class="flex justify-between text-sm text-slate-500 mb-2">
      <span id="progress-text">Soal 1 dari 10</span>
      <span id="progress-pct">0%</span>
    </div>
    <div class="w-full bg-slate-200 h-2 rounded-full">
      <div id="progress-bar" class="bg-blue-600 h-2 rounded-full transition-all duration-300" style="width:0%"></div>
    </div>
  </div>

  <!-- Card Soal -->
  <div class="bg-white rounded-3xl shadow-lg border border-slate-100 overflow-hidden">

    <!-- Kategori & Soal -->
    <div class="p-8 border-b border-slate-100">
      <span id="kategori-badge" class="px-3 py-1 bg-blue-100 text-blue-700 text-xs font-bold rounded-full uppercase tracking-wider"></span>
      <h2 id="pertanyaan" class="text-xl font-bold text-slate-800 mt-4 leading-relaxed"></h2>
    </div>

    <!-- Pilihan -->
    <div class="p-8 space-y-3" id="pilihan-container"></div>

    <!-- Navigasi -->
    <div class="bg-slate-50 px-8 py-5 flex justify-between items-center">
      <button onclick="kembali()" id="btn-kembali"
        class="flex items-center gap-2 px-5 py-2.5 text-slate-600 font-semibold hover:bg-slate-100 rounded-xl transition-all text-sm">
        ← Kembali
      </button>
      <button onclick="lanjut()" id="btn-lanjut"
        class="flex items-center gap-2 px-8 py-2.5 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 transition-all text-sm">
        Lanjut →
      </button>
    </div>

  </div>

  <!-- Tips -->
  <div class="mt-6 p-5 bg-white border border-slate-100 rounded-2xl shadow-sm flex gap-4">
    <span class="text-2xl">💡</span>
    <div>
      <p class="text-sm font-bold text-slate-700 mb-1">Tips Menjawab</p>
      <p class="text-xs text-slate-500 leading-relaxed">Jawab berdasarkan perasaan spontanmu. Tidak ada jawaban benar atau salah!</p>
    </div>
  </div>

</div>

<form id="form-assessment" action="proses_assessment.php" method="POST" style="display:none">
  <input type="hidden" name="skor_logika" id="input-logika"/>
  <input type="hidden" name="skor_kreatif" id="input-kreatif"/>
  <input type="hidden" name="skor_sosial" id="input-sosial"/>
</form>

<script>
const soal = [
  { kategori: "Logika & Analitis", pertanyaan: "Saat ada masalah rumit, kamu lebih suka...", pilihan: ["Menganalisis data dan fakta dulu", "Mencari solusi kreatif yang unik", "Mendiskusikan dengan orang lain", "Mengikuti prosedur yang sudah ada"], skor: ["logika","kreatif","sosial","logika"] },
  { kategori: "Kreatif & Seni", pertanyaan: "Waktu luangmu biasanya diisi dengan...", pilihan: ["Membaca buku sains atau teknologi", "Menggambar, musik, atau menulis", "Hang out dan ngobrol sama teman", "Mengorganisir jadwal dan rencana"], skor: ["logika","kreatif","sosial","logika"] },
  { kategori: "Sosial & Komunikasi", pertanyaan: "Dalam kelompok, kamu biasanya berperan sebagai...", pilihan: ["Pemikir yang menganalisis situasi", "Orang yang punya ide-ide segar", "Penghubung antar anggota tim", "Pengatur tugas dan jadwal"], skor: ["logika","kreatif","sosial","logika"] },
  { kategori: "Logika & Analitis", pertanyaan: "Pelajaran yang paling kamu sukai di sekolah...", pilihan: ["Matematika dan IPA", "Seni, musik, atau sastra", "IPS dan sosiologi", "Ekonomi dan akuntansi"], skor: ["logika","kreatif","sosial","logika"] },
  { kategori: "Kreatif & Seni", pertanyaan: "Kalau disuruh bikin proyek bebas, kamu pilih...", pilihan: ["Eksperimen sains atau coding", "Karya seni atau desain", "Acara sosial atau presentasi", "Laporan terstruktur dan rapi"], skor: ["logika","kreatif","sosial","logika"] },
  { kategori: "Sosial & Komunikasi", pertanyaan: "Kamu merasa paling puas ketika...", pilihan: ["Berhasil memecahkan soal sulit", "Menciptakan sesuatu yang indah", "Membantu orang lain", "Menyelesaikan target tepat waktu"], skor: ["logika","kreatif","sosial","logika"] },
  { kategori: "Logika & Analitis", pertanyaan: "Cara belajarmu yang paling efektif...", pilihan: ["Membaca dan menganalisis sendiri", "Belajar sambil berkreasi", "Diskusi dan tanya jawab", "Mencatat dan menghapal"], skor: ["logika","kreatif","sosial","logika"] },
  { kategori: "Kreatif & Seni", pertanyaan: "Impian karirmu lebih ke arah...", pilihan: ["Ilmuwan, programmer, atau engineer", "Seniman, desainer, atau penulis", "Guru, psikolog, atau dokter", "Manajer, akuntan, atau pengusaha"], skor: ["logika","kreatif","sosial","logika"] },
  { kategori: "Sosial & Komunikasi", pertanyaan: "Saat presentasi, kamu lebih suka...", pilihan: ["Memaparkan data dan grafik", "Presentasi yang visual dan kreatif", "Berinteraksi langsung dengan audiens", "Presentasi terstruktur dan sistematis"], skor: ["logika","kreatif","sosial","logika"] },
  { kategori: "Logika & Analitis", pertanyaan: "Teknologi bagimu adalah...", pilihan: ["Alat untuk memecahkan masalah", "Media untuk berkarya", "Cara untuk terhubung dengan orang", "Alat untuk efisiensi kerja"], skor: ["logika","kreatif","sosial","logika"] }
];

let current = 0;
let jawaban = [];
let skor = { logika: 0, kreatif: 0, sosial: 0 };

function tampilSoal() {
  const s = soal[current];
  document.getElementById('kategori-badge').textContent = s.kategori;
  document.getElementById('pertanyaan').textContent = s.pertanyaan;

  const container = document.getElementById('pilihan-container');
  container.innerHTML = '';
  const huruf = ['A','B','C','D'];

  s.pilihan.forEach((p, i) => {
    const dipilih = jawaban[current] === i;
    container.innerHTML += `
      <label class="option-label flex items-center gap-4 p-5 border-2 rounded-2xl cursor-pointer transition-all
        ${dipilih ? 'border-blue-600 bg-blue-50' : 'border-slate-100 bg-white hover:border-blue-200'}">
        <input type="radio" name="pilihan" value="${i}" class="hidden" ${dipilih ? 'checked' : ''}
          onchange="pilih(${i})"/>
        <div class="option-letter w-10 h-10 rounded-xl flex items-center justify-center font-bold text-sm flex-shrink-0
          ${dipilih ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-500'}">
          ${huruf[i]}
        </div>
        <p class="text-sm font-medium text-slate-700">${p}</p>
      </label>`;
  });

  // Progress
  const pct = Math.round((current / soal.length) * 100);
  document.getElementById('progress-bar').style.width = pct + '%';
  document.getElementById('progress-text').textContent = `Soal ${current+1} dari ${soal.length}`;
  document.getElementById('progress-pct').textContent = pct + '%';
  document.getElementById('btn-kembali').style.visibility = current === 0 ? 'hidden' : 'visible';
  document.getElementById('btn-lanjut').textContent = current === soal.length-1 ? 'Lihat Hasil →' : 'Lanjut →';
}

function pilih(i) {
  jawaban[current] = i;
  tampilSoal();
}

function lanjut() {
  if(jawaban[current] === undefined) {
    alert('Pilih jawaban dulu ya!');
    return;
  }
  // Hitung skor
  const kategoriSkor = soal[current].skor[jawaban[current]];
  skor[kategoriSkor]++;

  if(current < soal.length - 1) {
    current++;
    tampilSoal();
  } else {
    // Submit
    document.getElementById('input-logika').value = skor.logika;
    document.getElementById('input-kreatif').value = skor.kreatif;
    document.getElementById('input-sosial').value = skor.sosial;
    document.getElementById('form-assessment').submit();
  }
}

function kembali() {
  if(current > 0) {
    // Kurangi skor yang sudah dihitung
    if(jawaban[current-1] !== undefined) {
      const kategoriSkor = soal[current-1].skor[jawaban[current-1]];
      skor[kategoriSkor] = Math.max(0, skor[kategoriSkor]-1);
    }
    current--;
    tampilSoal();
  }
}

tampilSoal();
</script>

</body>
</html>
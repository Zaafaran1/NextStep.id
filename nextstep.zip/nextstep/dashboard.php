<?php
error_reporting(0);
session_start();
include "koneksi.php";

if(!isset($_SESSION['email'])){
    header("Location: login.html");
    exit();
}

$email = $_SESSION['email'];

// Ambil data user
$q_user = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");
$user = mysqli_fetch_assoc($q_user);
$user_id = $user['id'];

// Ambil profil
$q_profil = mysqli_query($conn, "SELECT * FROM profil_siswa WHERE user_id='$user_id'");
$profil = mysqli_fetch_assoc($q_profil);

// Ambil semua riwayat assessment
$q_assessment = mysqli_query($conn, "SELECT * FROM hasil_assessment WHERE user_id='$user_id' ORDER BY created_at DESC");
$total_assessment = mysqli_num_rows($q_assessment);

// Ambil assessment terakhir
$assessment_terakhir = mysqli_fetch_assoc($q_assessment);
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Dashboard | NextStep.id</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=Inter:wght@400;500;600&display=swap" rel="stylesheet"/>
  <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet"/>
  <style>
    body { font-family: 'Inter', sans-serif; background: #faf8ff; }
    .material-symbols-outlined { font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24; }
  </style>
</head>
<body class="min-h-screen">

<!-- Sidebar -->
<aside class="fixed left-0 top-0 h-full w-64 border-r border-slate-200 bg-slate-50 flex flex-col z-40">
  <div class="text-2xl font-black text-blue-600 px-6 py-8">NextStep.id</div>
  <nav class="flex-1 space-y-1 mt-4">
    <a href="dashboard.php" class="flex items-center gap-3 px-6 py-3 bg-blue-50 text-blue-700 border-r-4 border-blue-600 font-bold">
      <span class="material-symbols-outlined">dashboard</span> Dashboard
    </a>
    <a href="asessment.php" class="flex items-center gap-3 px-6 py-3 text-slate-600 hover:text-blue-600 hover:bg-slate-100 transition-all">
      <span class="material-symbols-outlined">quiz</span> Assessment
    </a>
    <a href="futurepath.php" class="flex items-center gap-3 px-6 py-3 text-slate-600 hover:text-blue-600 hover:bg-slate-100 transition-all">
      <span class="material-symbols-outlined">explore</span> Career Paths
    </a>
    <a href="profil.php" class="flex items-center gap-3 px-6 py-3 text-slate-600 hover:text-blue-600 hover:bg-slate-100 transition-all">
      <span class="material-symbols-outlined">person</span> Edit Profil
    </a>
  </nav>
  <div class="p-6">
    <a href="logout.php" class="w-full flex items-center justify-center gap-2 bg-red-50 text-red-600 border border-red-200 py-3 rounded-xl font-semibold hover:bg-red-100 transition-all">
      <span class="material-symbols-outlined">logout</span> Logout
    </a>
  </div>
</aside>

<!-- Main -->
<main class="ml-64 min-h-screen">

  <!-- Topbar -->
  <header class="sticky top-0 z-30 bg-white border-b border-slate-200 px-8 py-4 flex justify-between items-center">
    <div>
      <h1 class="text-xl font-bold text-slate-800">Pusat Data Siswa</h1>
      <p class="text-xs text-slate-500">Selamat datang kembali, <?= $profil['nama_lengkap'] ?? $user['username'] ?>!</p>
    </div>
    <div class="flex items-center gap-3">
      <div class="text-right">
        <p class="text-sm font-bold text-slate-800"><?= $profil['nama_lengkap'] ?? $user['username'] ?></p>
        <p class="text-xs text-slate-500"><?= $profil['sekolah'] ?? 'Belum isi profil' ?></p>
      </div>
      <div class="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-bold text-lg">
        <?= strtoupper(substr($profil['nama_lengkap'] ?? $user['username'], 0, 1)) ?>
      </div>
    </div>
  </header>

  <div class="p-8 max-w-7xl mx-auto">

    <!-- Info Cards -->
    <div class="grid grid-cols-3 gap-6 mb-8">

      <!-- Profil Card -->
      <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <div class="flex items-center gap-3 mb-4">
          <div class="p-2 bg-blue-50 text-blue-600 rounded-lg">
            <span class="material-symbols-outlined">person</span>
          </div>
          <p class="font-bold text-slate-700">Profil Siswa</p>
        </div>
        <p class="text-2xl font-extrabold text-slate-800"><?= $profil['nama_lengkap'] ?? '-' ?></p>
        <p class="text-sm text-slate-500 mt-1"><?= $profil['sekolah'] ?? '-' ?> • Kelas <?= $profil['kelas'] ?? '-' ?></p>
        <p class="text-sm text-slate-500 mt-1">📍 <?= $profil['kota'] ?? '-' ?></p>
      </div>

      <!-- Total Assessment Card -->
      <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <div class="flex items-center gap-3 mb-4">
          <div class="p-2 bg-purple-50 text-purple-600 rounded-lg">
            <span class="material-symbols-outlined">quiz</span>
          </div>
          <p class="font-bold text-slate-700">Total Assessment</p>
        </div>
        <p class="text-5xl font-extrabold text-slate-800"><?= $total_assessment ?></p>
        <p class="text-sm text-slate-500 mt-1">Kali mengikuti assessment</p>
        <a href="asessment.php" class="text-blue-600 text-sm font-bold mt-3 inline-block hover:underline">
          Ikuti lagi →
        </a>
      </div>

      <!-- Rekomendasi Card -->
      <div class="bg-blue-600 p-6 rounded-2xl shadow-sm text-white">
        <div class="flex items-center gap-3 mb-4">
          <div class="p-2 bg-white/20 rounded-lg">
            <span class="material-symbols-outlined">star</span>
          </div>
          <p class="font-bold">Rekomendasi Karir</p>
        </div>
        <p class="text-xl font-extrabold"><?= $assessment_terakhir['rekomendasi'] ?? 'Belum ada' ?></p>
        <p class="text-blue-200 text-sm mt-1">Berdasarkan assessment terakhir</p>
        <a href="futurepath.php" class="text-white text-sm font-bold mt-3 inline-block hover:underline">
          Lihat detail →
        </a>
      </div>

    </div>

    <!-- Skor Terakhir -->
    <?php if($assessment_terakhir): ?>
    <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm mb-8">
      <h3 class="font-bold text-slate-800 mb-6">Skor Assessment Terakhir</h3>
      <?php
        $total = $assessment_terakhir['skor_logika'] + $assessment_terakhir['skor_kreatif'] + $assessment_terakhir['skor_sosial'];
        $pct_logika = $total > 0 ? round(($assessment_terakhir['skor_logika']/$total)*100) : 0;
        $pct_kreatif = $total > 0 ? round(($assessment_terakhir['skor_kreatif']/$total)*100) : 0;
        $pct_sosial = $total > 0 ? round(($assessment_terakhir['skor_sosial']/$total)*100) : 0;
      ?>
      <div class="space-y-4">
        <div>
          <div class="flex justify-between text-sm mb-1">
            <span class="font-medium text-slate-700">🔵 Logika & Analitis</span>
            <span class="font-bold text-blue-600"><?= $pct_logika ?>%</span>
          </div>
          <div class="w-full bg-slate-100 h-3 rounded-full">
            <div class="bg-blue-500 h-3 rounded-full" style="width:<?= $pct_logika ?>%"></div>
          </div>
        </div>
        <div>
          <div class="flex justify-between text-sm mb-1">
            <span class="font-medium text-slate-700">🟣 Kreatif & Seni</span>
            <span class="font-bold text-purple-600"><?= $pct_kreatif ?>%</span>
          </div>
          <div class="w-full bg-slate-100 h-3 rounded-full">
            <div class="bg-purple-500 h-3 rounded-full" style="width:<?= $pct_kreatif ?>%"></div>
          </div>
        </div>
        <div>
          <div class="flex justify-between text-sm mb-1">
            <span class="font-medium text-slate-700">🟢 Sosial & Komunikasi</span>
            <span class="font-bold text-green-600"><?= $pct_sosial ?>%</span>
          </div>
          <div class="w-full bg-slate-100 h-3 rounded-full">
            <div class="bg-green-500 h-3 rounded-full" style="width:<?= $pct_sosial ?>%"></div>
          </div>
        </div>
      </div>
    </div>
    <?php endif; ?>

    <!-- Riwayat Assessment -->
    <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
      <h3 class="font-bold text-slate-800 mb-6">Riwayat Assessment</h3>
      <?php
      // Reset query
      $q_riwayat = mysqli_query($conn, "SELECT * FROM hasil_assessment WHERE user_id='$user_id' ORDER BY created_at DESC");
      ?>
      <?php if(mysqli_num_rows($q_riwayat) > 0): ?>
      <div class="space-y-3">
        <?php while($row = mysqli_fetch_assoc($q_riwayat)): ?>
        <div class="flex items-center justify-between p-4 bg-slate-50 rounded-xl border border-slate-100">
          <div class="flex items-center gap-4">
            <div class="w-10 h-10 bg-blue-100 text-blue-600 rounded-xl flex items-center justify-center">
              <span class="material-symbols-outlined">psychology</span>
            </div>
            <div>
              <p class="font-bold text-slate-800 text-sm"><?= $row['rekomendasi'] ?></p>
              <p class="text-xs text-slate-500"><?= date('d M Y, H:i', strtotime($row['created_at'])) ?></p>
            </div>
          </div>
          <div class="text-right">
            <p class="text-xs text-slate-500">Logika: <span class="font-bold text-blue-600"><?= $row['skor_logika'] ?></span></p>
            <p class="text-xs text-slate-500">Kreatif: <span class="font-bold text-purple-600"><?= $row['skor_kreatif'] ?></span></p>
            <p class="text-xs text-slate-500">Sosial: <span class="font-bold text-green-600"><?= $row['skor_sosial'] ?></span></p>
          </div>
        </div>
        <?php endwhile; ?>
      </div>
      <?php else: ?>
      <div class="text-center py-12 text-slate-400">
        <span class="material-symbols-outlined text-5xl">quiz</span>
        <p class="mt-3 font-medium">Belum ada riwayat assessment</p>
        <a href="asessment.php" class="mt-3 inline-block text-blue-600 font-bold hover:underline">Mulai sekarang →</a>
      </div>
      <?php endif; ?>
    </div>

  </div>
</main>

</body>
</html>
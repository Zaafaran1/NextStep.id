<?php
error_reporting(0);
ini_set('display_errors', 0);
session_start();

if(!isset($_SESSION['email'])){
    header("Location: login.html");
    exit();
}

$rekomendasi = $_SESSION['rekomendasi'];
$skor_logika = $_SESSION['skor_logika'];
$skor_kreatif = $_SESSION['skor_kreatif'];
$skor_sosial = $_SESSION['skor_sosial'];
$total = $skor_logika + $skor_kreatif + $skor_sosial;

// Hitung persentase
$pct_logika = $total > 0 ? round(($skor_logika/$total)*100) : 0;
$pct_kreatif = $total > 0 ? round(($skor_kreatif/$total)*100) : 0;
$pct_sosial = $total > 0 ? round(($skor_sosial/$total)*100) : 0;

// Tentukan detail rekomendasi
if($skor_logika >= $skor_kreatif && $skor_logika >= $skor_sosial){
    $judul = "Analis Data / Engineer";
    $deskripsi = "Kamu memiliki kemampuan logika dan analitis yang kuat. Cocok di bidang teknologi, sains, dan data.";
    $skills = ["Python", "SQL", "Matematika", "Logika", "Problem Solving"];
    $warna = "blue";
    $icon = "💻";
    $gaji = "Rp 8.5M - 18M";
    $match = $pct_logika + 50;
} elseif($skor_kreatif >= $skor_logika && $skor_kreatif >= $skor_sosial){
    $judul = "Desainer / Seniman / Penulis";
    $deskripsi = "Kamu memiliki jiwa kreatif yang tinggi. Cocok di bidang seni, desain, dan komunikasi kreatif.";
    $skills = ["Desain Grafis", "Kreativitas", "Storytelling", "Adobe Suite", "Ilustrasi"];
    $warna = "purple";
    $icon = "🎨";
    $gaji = "Rp 6M - 15M";
    $match = $pct_kreatif + 50;
} else {
    $judul = "Guru / Psikolog / Konselor";
    $deskripsi = "Kamu memiliki empati dan kemampuan sosial yang tinggi. Cocok di bidang pendidikan dan pelayanan sosial.";
    $skills = ["Komunikasi", "Empati", "Public Speaking", "Konseling", "Kepemimpinan"];
    $warna = "green";
    $icon = "🤝";
    $gaji = "Rp 5M - 12M";
    $match = $pct_sosial + 50;
}

if($match > 99) $match = 99;
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>NextStep.id - Hasil Assessment</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=Inter:wght@400;500;600&display=swap" rel="stylesheet"/>
  <style>
    body { font-family: 'Inter', sans-serif; background: #f8fafc; }
  </style>
</head>
<body class="min-h-screen p-6 flex items-center justify-center">

<div class="w-full max-w-2xl space-y-6">

  <!-- Header -->
  <div class="text-center">
    <h1 class="text-3xl font-extrabold text-blue-600 mb-1">NextStep.id</h1>
    <p class="text-slate-500 text-sm">Hasil Assessment Kamu</p>
  </div>

  <!-- Hasil Utama -->
  <div class="bg-blue-600 rounded-3xl p-8 text-white text-center shadow-xl">
    <div class="text-6xl mb-4"><?= $icon ?></div>
    <div class="text-xs font-bold uppercase tracking-wider bg-white/20 px-4 py-1 rounded-full inline-block mb-4">
      Rekomendasi Terbaik
    </div>
    <h2 class="text-3xl font-extrabold mb-2"><?= $judul ?></h2>
    <p class="text-blue-100 text-sm mb-6"><?= $deskripsi ?></p>
    <div class="text-6xl font-black"><?= $match ?>%</div>
    <p class="text-blue-200 text-sm">Match Score</p>
  </div>

  <!-- Skor Per Kategori -->
  <div class="bg-white rounded-3xl p-8 shadow border border-slate-100">
    <h3 class="font-bold text-slate-800 mb-6">Skor Per Kategori</h3>

    <div class="space-y-4">
      <div>
        <div class="flex justify-between text-sm mb-1">
          <span class="font-medium text-slate-700">🔵 Logika & Analitis</span>
          <span class="font-bold text-blue-600"><?= $pct_logika ?>%</span>
        </div>
        <div class="w-full bg-slate-100 h-3 rounded-full">
          <div class="bg-blue-500 h-3 rounded-full" style="width:<?= $pct_logika ?>%"></div>
        </div>
      </div>

      <div>
        <div class="flex justify-between text-sm mb-1">
          <span class="font-medium text-slate-700">🟣 Kreatif & Seni</span>
          <span class="font-bold text-purple-600"><?= $pct_kreatif ?>%</span>
        </div>
        <div class="w-full bg-slate-100 h-3 rounded-full">
          <div class="bg-purple-500 h-3 rounded-full" style="width:<?= $pct_kreatif ?>%"></div>
        </div>
      </div>

      <div>
        <div class="flex justify-between text-sm mb-1">
          <span class="font-medium text-slate-700">🟢 Sosial & Komunikasi</span>
          <span class="font-bold text-green-600"><?= $pct_sosial ?>%</span>
        </div>
        <div class="w-full bg-slate-100 h-3 rounded-full">
          <div class="bg-green-500 h-3 rounded-full" style="width:<?= $pct_sosial ?>%"></div>
        </div>
      </div>
    </div>
  </div>

  <!-- Skills -->
  <div class="bg-white rounded-3xl p-8 shadow border border-slate-100">
    <h3 class="font-bold text-slate-800 mb-4">Skill yang Perlu Dikembangkan</h3>
    <div class="flex flex-wrap gap-3">
      <?php foreach($skills as $skill): ?>
        <span class="px-4 py-2 bg-slate-50 border border-slate-200 rounded-full text-sm font-semibold text-slate-700">
          <?= $skill ?>
        </span>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Gaji -->
  <div class="bg-white rounded-3xl p-8 shadow border border-slate-100 flex items-center justify-between">
    <div>
      <p class="text-xs text-slate-400 font-bold uppercase tracking-wider mb-1">Proyeksi Gaji</p>
      <p class="text-2xl font-extrabold text-slate-800"><?= $gaji ?></p>
      <p class="text-xs text-slate-500 mt-1">Estimasi per bulan (Entry - Senior)</p>
    </div>
    <div class="text-5xl">💰</div>
  </div>

  <!-- Tombol -->
  <div class="flex gap-4">
    <a href="asessment.php" class="flex-1 text-center py-4 border-2 border-blue-600 text-blue-600 font-bold rounded-2xl hover:bg-blue-50 transition-all">
      Ulangi Assessment
    </a>
    <a href="web.html" class="flex-1 text-center py-4 bg-blue-600 text-white font-bold rounded-2xl hover:bg-blue-700 transition-all">
      Kembali ke Beranda
    </a>
    <a href="dashboard.php" class="flex-1 text-center py-4 bg-blue-600 text-white font-bold rounded-2xl hover:bg-blue-700 transition-all">
  Lihat Dashboard
</a>
  </div>

</div>

</body>
</html>
<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

include "koneksi.php";

$email = $_POST['email'];
$password = $_POST['password'];

$query = mysqli_query($conn,
"SELECT * FROM users
WHERE email='$email'
AND password='$password'");

if(!$query){
    die(mysqli_error($conn));
}

$data = mysqli_num_rows($query);

if($data > 0){

    $_SESSION['email'] = $email;

    header("Location: dashboard.php");
}else{

    echo "Email atau password salah";

}
?>
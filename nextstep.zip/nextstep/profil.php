<?php
session_start();
include "koneksi.php";

if(!isset($_SESSION['email'])){
    header("Location: login.html");
    exit();
}

// Proses form
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $email = $_SESSION['email'];
    $nama = $_POST['nama_lengkap'];
    $sekolah = $_POST['sekolah'];
    $kelas = $_POST['kelas'];
    $kota = $_POST['kota'];

    // Ambil user_id
    $q = mysqli_query($conn, "SELECT id FROM users WHERE email='$email'");
    $user = mysqli_fetch_assoc($q);
    $user_id = $user['id'];

    // Simpan profil
    $cek = mysqli_query($conn, "SELECT id FROM profil_siswa WHERE user_id='$user_id'");
    if(mysqli_num_rows($cek) > 0){
        mysqli_query($conn, "UPDATE profil_siswa SET 
            nama_lengkap='$nama', sekolah='$sekolah', 
            kelas='$kelas', kota='$kota' 
            WHERE user_id='$user_id'");
    } else {
        mysqli_query($conn, "INSERT INTO profil_siswa 
            (user_id, nama_lengkap, sekolah, kelas, kota)
            VALUES('$user_id','$nama','$sekolah','$kelas','$kota')");
    }

    $_SESSION['nama'] = $nama;
    header("Location: asessment.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>NextStep.id - Lengkapi Profil</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=Inter:wght@400;500;600&display=swap" rel="stylesheet"/>
  <style>
    body { font-family: 'Inter', sans-serif; background: #f8fafc; }
  </style>
</head>
<body class="min-h-screen flex items-center justify-center p-6">

<div class="w-full max-w-lg">

  <!-- Header -->
  <div class="text-center mb-8">
    <h1 class="text-3xl font-extrabold text-blue-600 mb-1">NextStep.id</h1>
    <p class="text-slate-500 text-sm">Lengkapi profilmu sebelum mulai!</p>
  </div>

  <!-- Card -->
  <div class="bg-white rounded-3xl shadow-lg border border-slate-100 p-8">
    <h2 class="text-xl font-bold text-slate-800 mb-6">Data Diri</h2>

    <form method="POST" class="space-y-5">

      <div>
        <label class="block text-sm font-semibold text-slate-700 mb-2">Nama Lengkap</label>
        <input type="text" name="nama_lengkap" required
          class="w-full px-4 py-3 border-2 border-slate-100 rounded-xl text-sm focus:border-blue-500 outline-none transition-all"
          placeholder="Masukkan nama lengkap"/>
      </div>

      <div>
        <label class="block text-sm font-semibold text-slate-700 mb-2">Asal Sekolah</label>
        <input type="text" name="sekolah" required
          class="w-full px-4 py-3 border-2 border-slate-100 rounded-xl text-sm focus:border-blue-500 outline-none transition-all"
          placeholder="Contoh: SMAN 1 Bandung"/>
      </div>

  

      <div>
        <label class="block text-sm font-semibold text-slate-700 mb-2">Kota</label>
        <input type="text" name="kota" required
          class="w-full px-4 py-3 border-2 border-slate-100 rounded-xl text-sm focus:border-blue-500 outline-none transition-all"
          placeholder="Contoh: Bandung"/>
      </div>

      <button type="submit"
        class="w-full py-4 bg-blue-600 text-white font-bold rounded-2xl hover:bg-blue-700 transition-all mt-2">
        Mulai Assessment →
      </button>

    </form>
  </div>

</div>

</body>
</html>
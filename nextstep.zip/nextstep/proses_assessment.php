<?php
session_start();
include "koneksi.php";

// Cek session
if(!isset($_SESSION['email'])){
    header("Location: http://localhost/nextstep/login.html");
    exit();
}

$email = $_SESSION['email'];
$skor_logika = isset($_POST['skor_logika']) ? (int)$_POST['skor_logika'] : 0;
$skor_kreatif = isset($_POST['skor_kreatif']) ? (int)$_POST['skor_kreatif'] : 0;
$skor_sosial = isset($_POST['skor_sosial']) ? (int)$_POST['skor_sosial'] : 0;

// Tentukan rekomendasi
$max = max($skor_logika, $skor_kreatif, $skor_sosial);
if($max == $skor_logika) $rekomendasi = "Analis Data / Engineer / Programmer";
elseif($max == $skor_kreatif) $rekomendasi = "Desainer / Seniman / Penulis";
else $rekomendasi = "Guru / Psikolog / Konselor";

// Ambil user_id
$q = mysqli_query($conn, "SELECT id FROM users WHERE email='$email'");
$user = mysqli_fetch_assoc($q);
$user_id = $user['id'];

// Simpan ke database
mysqli_query($conn, "INSERT INTO hasil_assessment
(user_id, skor_logika, skor_kreatif, skor_sosial, rekomendasi)
VALUES('$user_id','$skor_logika','$skor_kreatif','$skor_sosial','$rekomendasi')");

// Simpan ke session
$_SESSION['rekomendasi'] = $rekomendasi;
$_SESSION['skor_logika'] = $skor_logika;
$_SESSION['skor_kreatif'] = $skor_kreatif;
$_SESSION['skor_sosial'] = $skor_sosial;

// Redirect
header("Location: http://localhost/nextstep/futurepath.php");
exit();
?>
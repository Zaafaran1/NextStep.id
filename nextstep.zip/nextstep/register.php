<?php
session_start();
include "koneksi.php";

$username = $_POST['username'];
$email = $_POST['email'];
$password = $_POST['password'];

$query = mysqli_query($conn,
"INSERT INTO users(username, email, password)
VALUES('$username','$email','$password')");

if($query){
    $_SESSION['email'] = $email;
    header("Location: profil.php");
    exit();
} else {
    echo "Register gagal";
}
?>